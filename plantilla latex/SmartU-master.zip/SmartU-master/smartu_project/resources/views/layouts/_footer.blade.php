<div class="container">
    <hr>
    <p class="text-muted">{!! __("&copy 2017 - Juanjo Jiménez and the SmartU team") !!} - <a href="{{ route('about') }}">{{ __("About SmartU") }}</a></p>
    <br>
</div>
