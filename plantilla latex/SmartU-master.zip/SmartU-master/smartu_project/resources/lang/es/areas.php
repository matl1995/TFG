<?php

return [

    'computer_science' => 'Informática',
    'graphic_design' => 'Diseño gráfico',
    'architecture' => 'Arquitectura',
    'communications' => 'Comunicaciones',
    'audiovisuals' => 'Audiovisuales',
    'business' => 'Empresariales',

];
