<?php

return [

    'featured' => 'Destacados',
    'recent' => 'Últimos proyectos',
    'search' => 'Buscar por área',
    'by' => 'de',
    'projects' => 'proyecto|proyectos',

];
