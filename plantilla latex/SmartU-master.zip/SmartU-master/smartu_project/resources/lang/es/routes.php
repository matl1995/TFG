<?php

return [

    'about' => 'acerca-de',
    'dashboard' => 'inicio',
    'profile' => 'perfil',
    'login' => 'iniciar-sesion',
    'logout' => 'cerrar-sesion',
    'register' => 'registrarse',
    'password.reset' => 'contraseña/recuperar',
    'password.email' => 'contraseña/email',
    'projects' => 'proyectos',

];
