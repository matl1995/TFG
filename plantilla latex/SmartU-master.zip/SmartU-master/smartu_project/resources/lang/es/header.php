<?php

return [

    'toggle_nav' => 'Activar navegación',
    'home' => 'Inicio',
    'projects' => 'Proyectos',
    'login' => 'Iniciar sesión',
    'logout' => 'Cerrar sesión',
    'register' => 'Registrarse',
    'profile' => 'Perfil',
    'areas' => 'Áreas',

];
