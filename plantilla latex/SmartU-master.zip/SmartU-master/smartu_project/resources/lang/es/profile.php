<?php

return [

    'title' => "Perfil de :Firstname :Lastname",
    
];
