<?php

return [

    'about' => 'about',
    'dashboard' => 'dashboard',
    'profile' => 'profile',
    'login' => 'login',
    'logout' => 'logout',
    'register' => 'register',
    'password.reset' => 'password/reset',
    'password.email' => 'password/email',

];
