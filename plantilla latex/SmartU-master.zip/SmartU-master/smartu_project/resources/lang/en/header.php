<?php

return [

    'toggle_nav' => 'Toggle navigation',
    'home' => 'Home',
    'projects' => 'Projects',
    'login' => 'Log in',
    'logout' => 'Log out',
    'register' => 'Register',
    'profile' => 'Profile',
    'areas' => 'Areas',

];
