<?php

return [

    'computer_science' => 'Computer Science',
    'graphic_design' => 'Graphic Design',
    'architecture' => 'Architecture',
    'communications' => 'Communications',
    'audiovisuals' => 'Audiovisuals',
    'business' => 'Business',

];
