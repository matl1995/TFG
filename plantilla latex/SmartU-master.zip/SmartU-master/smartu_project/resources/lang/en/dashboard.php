<?php

return [

    'featured' => 'Featured',
    'recent' => 'Recent Projects',
    'search' => 'Search by Area',
    'by' => 'by',
    'projects' => 'project|projects',

];
